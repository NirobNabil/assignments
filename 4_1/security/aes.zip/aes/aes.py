import numpy as np
from aes_util import *
from aes_const import *


########### ENCRRYPTION ############

def encrypt(initial_state, initial_key):
  """
  AES encryption function for 128-bit input plaintext.

  Args:
  plaintext: A list of 16 bytes (integers) representing the plaintext.
  round_keys: A list of 11 round keys (each key is a 4x4 matrix).

  Returns:
  The ciphertext obtained by encrypting the plaintext using AES algorithm.
  """
  print(initial_key, initial_state)

  # Reshape the initial key into a 4x4 matrix :
  key_matrix = generatingMatrixFromList(initial_key)

  # generating round keys :
  round_keys = keyExpansion(key_matrix)

  state_matrix = transpose( generatingMatrixFromList(initial_state) )
  new_state_matrix = xorMatrix(state_matrix, transpose( round_keys[0] ) )

  # new_state_matrix = np.array(new_state_matrix).transpose().tolist()

  for i in range(1,10):
    new_state_matrix = subMatrix(new_state_matrix)

    new_state_matrix =  shiftMatrixRow(new_state_matrix)

    new_state_matrix = mixColumn(mix_col_matrix, new_state_matrix)

    new_state_matrix = xorMatrix(new_state_matrix, transpose( round_keys[i] ) )

  new_state_matrix = subMatrix(new_state_matrix)

  new_state_matrix =  shiftMatrixRow(new_state_matrix)

  new_state_matrix = xorMatrix(new_state_matrix, transpose( round_keys[10] ) )

  return new_state_matrix




########### DECRYPTION #################

# @title
# Example AES encryption with 128-bit input plaintext

def decrypt(cipher_matrix, initial_key):

  # Reshape the initial key into a 4x4 matrix :
  key_matrix = generatingMatrixFromList(initial_key)

  # generating round keys :
  round_keys = keyExpansion(key_matrix)
  round_keys.reverse()

  # for i in range (11):
  #   print("round ", i, " ", round_keys[i])


  # cipher_matrix = transpose(cipher_matrix)

  # print_matrix(round_keys)

  new_state_matrix = xorMatrix(cipher_matrix, transpose( round_keys[0]) )
  # print("after first inverse add round key : ")
  # print_matrix(new_state_matrix)
  # print()

  # new_state_matrix = np.array(new_state_matrix).transpose().tolist()

  for i in range(1,10):
    new_state_matrix = invShiftRow(new_state_matrix)
    # print("after inverse shift matrix row : ")
    # print_matrix(new_state_matrix)
    # print()

    new_state_matrix = invSubMatrix(new_state_matrix)
    # print("after inverse substitution : ")
    # print_matrix(new_state_matrix)
    # print()

    new_state_matrix = xorMatrix(new_state_matrix, transpose( round_keys[i] ) )
    # print("after inverse add round key : ")
    # print_matrix(new_state_matrix)
    # print()

    new_state_matrix = invMixColumn(inv_mix_col_matrix, new_state_matrix)
    # print("after inverse mix column : ")
    # print_matrix(new_state_matrix)
    # print()


  # round 10 of aes :
  new_state_matrix = invShiftRow(new_state_matrix)
  # print("after inverse shift matrix row : ")
  # print_matrix(new_state_matrix)
  # print()

  new_state_matrix = invSubMatrix(new_state_matrix)
  # print("after inverse substitution : ")
  # print_matrix(new_state_matrix)
  # print()

  new_state_matrix = xorMatrix(new_state_matrix, transpose(round_keys[10]) )
  # print("after inverse add round key : ")
  # print_matrix(new_state_matrix)
  # print()

  return new_state_matrix# @title
# Example AES encryption with 128-bit input plaintext

def decrypt(cipher_matrix, initial_key):

  # Reshape the initial key into a 4x4 matrix :
  key_matrix = generatingMatrixFromList(initial_key)

  # generating round keys :
  round_keys = keyExpansion(key_matrix)
  round_keys.reverse()

  # for i in range (11):
  #   print("round ", i, " ", round_keys[i])


  # cipher_matrix = transpose(cipher_matrix)

  # print_matrix(round_keys)

  new_state_matrix = xorMatrix(cipher_matrix, transpose( round_keys[0]) )
  # print("after first inverse add round key : ")
  # print_matrix(new_state_matrix)
  # print()

  # new_state_matrix = np.array(new_state_matrix).transpose().tolist()

  for i in range(1,10):
    new_state_matrix = invShiftRow(new_state_matrix)
    # print("after inverse shift matrix row : ")
    # print_matrix(new_state_matrix)
    # print()

    new_state_matrix = invSubMatrix(new_state_matrix)
    # print("after inverse substitution : ")
    # print_matrix(new_state_matrix)
    # print()

    new_state_matrix = xorMatrix(new_state_matrix, transpose( round_keys[i] ) )
    # print("after inverse add round key : ")
    # print_matrix(new_state_matrix)
    # print()

    new_state_matrix = invMixColumn(inv_mix_col_matrix, new_state_matrix)
    # print("after inverse mix column : ")
    # print_matrix(new_state_matrix)
    # print()


  # round 10 of aes :
  new_state_matrix = invShiftRow(new_state_matrix)
  # print("after inverse shift matrix row : ")
  # print_matrix(new_state_matrix)
  # print()

  new_state_matrix = invSubMatrix(new_state_matrix)
  # print("after inverse substitution : ")
  # print_matrix(new_state_matrix)
  # print()

  new_state_matrix = xorMatrix(new_state_matrix, transpose(round_keys[10]) )
  # print("after inverse add round key : ")
  # print_matrix(new_state_matrix)
  # print()

  return new_state_matrix
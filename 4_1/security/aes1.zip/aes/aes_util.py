
import numpy as np
from aes_util import *
from aes_const import *

# converting hex num to integer
def hexToInt(hex_num):
  hex_string = hex(hex_num)
  integer_value = int(hex_string, 16)
  return integer_value


# converting integer num to hex
def intToHex(integer_value):
    hex_string = hex(integer_value)
    return hex_string

# generating matrix from list :
def generatingMatrixFromList(initial_key):
    """
    Convert the initial key list into a 4x4 matrix.

    Args:
    initial_key: A list of 16 bytes representing the initial key.

    Returns:
    A 4x4 matrix representing the initial key.
    """
    key_matrix = [
        [initial_key[0], initial_key[1], initial_key[2], initial_key[3]],
        [initial_key[4], initial_key[5], initial_key[6], initial_key[7]],
        [initial_key[8], initial_key[9], initial_key[10], initial_key[11]],
        [initial_key[12], initial_key[13], initial_key[14], initial_key[15]]
    ]
    return key_matrix

# calculating xor of two hex strings :
def xorHexStrings(hex_str1, hex_str2):

    int1 = int(hex_str1, 16)
    int2 = int(hex_str2, 16)
    # Perform XOR operation
    result = int1 ^ int2
    # Convert result back to hexadecimal string
    hex_result = hex(result)[2:]  # Remove '0x' prefix
    # Pad with leading zeros if necessary
    hex_result = hex_result.zfill(max(len(hex_str1), len(hex_str2)) - 2)
    hex_result = '0x' + hex_result
    return hex_result


# Helper functions for key expansion :
def rotWord(word):
    return word[1:] + [word[0]]


# Helper functions for substitution :
def subWord(word):
    for i in range(4):
      char1 = word[i][2]
      char2 = word[i][3]
      word[i] = Sbox[(hex_to_int_mapping[char1]*16)+hex_to_int_mapping[char2]]
    return word


# key expansion function
def keyExpansion(key):
    round_keys = [key]

    def xorHexWord( w1, w2 ):
        return [ xorHexStrings(w1[i] , w2[i]) for i in range(4) ]

    def g( w, round_i ):
        temp = w.copy()
        temp = rotWord(temp)
        # print("rotword: ", temp)
        temp = subWord(temp)
        # print(f"subword[{round_i}]: ", temp)
        result = xorHexWord(temp , rcon[round_i - 1])
        # print(f"result[{round_i}]: ", result)
        return result


    def generate_round_key( round_i ):
        prev = round_keys[round_i-1]
        w0, w1, w2, w3 = prev
        w4 = xorHexWord( w0, g(w3, round_i) )
        w5 = xorHexWord( w4, w1 )
        w6 = xorHexWord( w5, w2 )
        w7 = xorHexWord( w6, w3 )
        # print(f"Rounds [{round_i}]: ", [ w0, w1, w2, w3, w4, w5, w6, w7 ] )
        return [ w4, w5, w6, w7 ]


    for round_i in range(1,11):
        round_keys.append( generate_round_key( round_i ) )

    return round_keys


# calculating xor of two matrix :
def xorMatrix(mat1, mat2) :
  for i in range (4):
    for j in range (4):
      mat1[i][j] = xorHexStrings(mat1[i][j], mat2[i][j])
  return mat1


# calculating substitution of a matrix :
def subMatrix(state):
  for i in range (Nb):
    state[i] = subWord(state[i])
  return state


# performing shift matrix row operation :
def shiftMatrixRow(state):
    for i in range(1, 4):
        state[i] = state[i][i:] + state[i][:i]
    return state


def multiplyHexStrings(hex_str1, hex_str2):

    # Convert hexadecimal strings to integers
    int1 = int(hex_str1, 16)
    int2 = int(hex_str2, 16)

    # Perform multiplication
    result = int1 * int2

    # Convert result back to hexadecimal string
    hex_result = hex(result)[2:]  # Remove '0x' prefix
    hex_result = hex_result.zfill(max(len(hex_str1), len(hex_str2)) - 2)

    return hex_result

# assumin **b** will always be 1 or 2 or 3
def gmul(a, b):
  # print("before: ", a,b)
  a = int(a, 16)
  b = int(b, 16)
  # print("after: ", a,b)
  if b == 1:
      return hex(a)
  tmp = (a << 1) & 0xff
  if b == 2:
      return hex(tmp) if a < 128 else xorHexStrings( hex(tmp), hex(0x1b) )
  if b == 3:
      return xorHexStrings( gmul(hex(a), hex(2)), hex(a) )


# multiplying two matrix :
def matrix_multiply(matrix1, matrix2):
    result = [['0x00' for _ in range(4)] for _ in range(4)]  # Initialize result matrix with zeros
    for i in range(4):
        for j in range(4):
            # Compute the dot product of the ith row of matrix1 and the jth column of matrix2
            for k in range(4):
              gmul_ans = gmul(matrix2[k][j], matrix1[i][k])
              result[i][j] = xorHexStrings(result[i][j], gmul_ans ) # Perform XOR operation for each element

    return result

# applying mix column operation :
def mixColumn(mix_col_matrix,state):
   return matrix_multiply(mix_col_matrix,state)

# function for printing matrix :
def print_matrix(matrix):
  for row in matrix:
    print(row)

        
def plaintext_ascii_to_hex( plaintext ):
    plaintext_hex = []
    for i in plaintext:
        plaintext_hex.append( hex(ord(i))[2:] )
    return "".join(plaintext_hex)

# function to convert a plaintext to hex-string list :
def plaintext_hex_to_blocks(key_hex):
  idx = 0
  ret = []
  while idx<len(key_hex):

    key_list = [key_hex[i:i+2] for i in range(idx, min(idx+31,len(key_hex)), 2)]

    while(len(key_list)<16):
      key_list.append("20")

    key_list = [f'0x{byte}' for byte in key_list]
    idx+=32
    ret.append(key_list)
  return ret


import random
def generate_random_key( seed=0 ):
    random.seed(seed)
    key = []
    for _ in range(4*4):
        key.append( hex( random.randint(0, 2**7) )[2:].rjust(2, "0") )

    return plaintext_hex_to_blocks("".join(key))[0]

def transpose( mat ):
    return np.array(mat).transpose().tolist()




# @title
def invShiftRow(state):
    for i in range(1, 4):
        state[i] = state[i][-i:] + state[i][:-i]
    return state


def invSubWord(word):
    for i in range(4):
      char1 = word[i][2]
      char2 = word[i][3]
      word[i] = InvSbox[(hex_to_int_mapping[char1]*16)+hex_to_int_mapping[char2]]
    return word


def invSubMatrix(state):
  for i in range (Nb):
    state[i] = invSubWord(state[i])
  return state


# finite field multiplication within 2^8
def inv_gmul(x, y):

    x = int( x, 16 )
    y = int( y, 16 )

    p = 0b100011011             # mpy modulo x^8+x^4+x^3+x+1
    m = 0                       # m will be product
    for i in range(8):
        m = m << 1
        if m & 0b100000000:
            m = m ^ p
        if y & 0b010000000:
            m = m ^ x
        y = y << 1
    return hex(m)



def inv_matrix_multiply(matrix1, matrix2):
    result = [['0x00' for _ in range(4)] for _ in range(4)]  # Initialize result matrix with zeros
    for i in range(4):
        for j in range(4):
            # Compute the dot product of the ith row of matrix1 and the jth column of matrix2
            for k in range(4):
              gmul_ans = inv_gmul(matrix2[k][j], matrix1[i][k])
              result[i][j] = xorHexStrings(result[i][j], gmul_ans ) # Perform XOR operation for each element

    return result


# applying mix column operation :
def invMixColumn( inv_mix_col_matrix, state ):
    return inv_matrix_multiply(inv_mix_col_matrix,state)


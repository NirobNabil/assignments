import random
import sympy
import time


def generate_prime(bit_size):
    def is_prime(num):
        if num <= 1:
            return False
        if num <= 3:
            return True
        if num % 2 == 0 or num % 3 == 0:
            return False
        i = 5
        while i * i <= num:
            if num % i == 0 or num % (i + 2) == 0:
                return False
            i += 6
        return True

    min_value = 2 ** (bit_size - 1)
    max_value = 2 ** bit_size - 1
    prime = random.randint(min_value, max_value)
    while not is_prime(prime):
        prime = random.randint(min_value, max_value)
    return prime

def generate_keypair(bit_size):
    p = generate_prime(bit_size // 2)
    q = generate_prime(bit_size // 2)

    n = p * q

    phi_n = (p - 1) * (q - 1)

    min_e = 2 ** (bit_size // 2 - 1)
    max_e = 2 ** (bit_size // 2)
    e = random.randint(min_e, max_e)
    while e % phi_n == 0 or sympy.gcd(e, phi_n) != 1:
        e = random.randint(min_e, max_e)

    d = sympy.mod_inverse(e, phi_n)

    public_key = (e, n)
    private_key = (d, n)

    return public_key, private_key

def encrypt(public_key, plaintext):
    e, n = public_key
    ciphertext = [pow(ord(char), e, n) for char in plaintext]
    return ciphertext

def decrypt(private_key, ciphertext):
    d, n = private_key
    plaintext = ''.join([chr(pow(char, d, n)) for char in ciphertext])
    return plaintext


